const lang_function = `
    public lang():string
    {
        return this[window["lang"]] || "--";
    }
    public lang_1(param:string):string
    {
        return this[window["lang"]].replace("{0}",param) || "--";
    }
    public lang_2(param1:string,param2:string):string
    {
        let str = this[window["lang"]].replace("{0}",param1);
        return str.replace("{1}",param2) || "--";
    }
    public lang_3(param1:string,param2:string,param3:string)
    {
        let str = this[window["lang"]].replace("{0}",param1);
        str = str.replace("{1}",param2);
        return str.replace("{2}",param3) || "--";
    }
    public lang_4(param1:string,param2:string,param3:string,param4:string)
    {
        let str = this[window["lang"]].replace("{0}",param1);
        str = str.replace("{1}",param2);
        str = str.replace("{2}",param3);
        return str.replace("{3}",param4) || "--";
    }
`;

module.exports = lang_function;