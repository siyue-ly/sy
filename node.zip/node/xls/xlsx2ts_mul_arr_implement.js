
let xlsl_util = require("./xlsl_util");
let log = require("./../utils/log");

let M = {};

M.parse = function(file_name,sheet_item,write_dir_path)
{
    let str = "";
    str += xlsl_util.get_row_interface(file_name,sheet_item);
    str += xlsl_util.get_row_class(file_name,sheet_item);
    str += xlsl_util.getMulArrContent(file_name,sheet_item);
    str += xlsl_util.getMulArrName(file_name);
    str += xlsl_util.getMountArrayToWindow(file_name);
    return str;
}

module.exports = M;