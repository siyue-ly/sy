let colum_type = require("./types/colum_type");
let lang_fun_content = require("./lang_fun_content");
let lang_file_name = "lang";
let utils = require("./../utils/utils");
let path = require("path");
let ts_head = utils.get_ts_head();
let log = require("./../utils/log");


let M = {};


M.getIndexColum = function(item) {
    let data_array = item.data;
    if (!data_array[2]) {
        return -1;
    }
    for (let i = 0; i < data_array[2].length; ++i) {
        if (data_array[2][i] == "index") {
            return i;
        }
    }
    return -1;
}

//枚举index 
M.getIndexEnum = function(item) {
    let content = "";
    let colum = M.getIndexColum(item);
    if (colum == -1) {
        return content;
    }
    let data_array = item.data;
    let is_string = data_array[1][colum] == "string"
    content = `export enum ${data_array[0][colum]}\n`;

    content += "{\n";

    for (let i = 3; i < data_array.length; ++i) {
        if (data_array[i].length == 0) {
            continue;
        }
        if (!is_string)
            content += `\t${data_array[i][0]} = ${data_array[i][colum]},\n`;
        else
            content += `\t${data_array[i][0]} = "${data_array[i][colum]}",\n`;
    }
    content += "}\n";
    return content;
}

//枚举主键类
M.getPrimaryEnum = function(item) {
    let is_can_wirte_enum = false;
    let data_array = item.data;
    if (data_array[1] && data_array[1][0] && colum_type.isStringType(data_array[1][0])) {
        is_can_wirte_enum = true;
    }
    if (is_can_wirte_enum == false) {
        return "";
    }
    let enum_name = data_array[0][0];
    if (!enum_name) {
        return "";
    }
    let content = `export enum ${enum_name}\n`;
    content += "{\n";

    for (let i = 3; i < data_array.length; ++i) {
        data_array[i][0];
        if (data_array[i].length == 0) {
            continue;
        }
        content += `\t${data_array[i][0]} = \`${data_array[i][0]}\`,\n`;

    }
    content += "}\n\n";
    return content;

}

M.getRowClassName = function(file_name) {
    return `${file_name}_item`;
}

M.get_row_interface = function(file_name, sheet_item) {
    let row_array = sheet_item["data"];
    if (!row_array) {
        log.log_error(`get sheet_item['data'] error!`);
        return "";
    }
    if (row_array.length < 4) {
        log.log_error(`sheet_item row_array.length is smaller than four!`);
        return "";
    }
    let colum_array_0 = row_array[0];
    let colum_array_1 = row_array[1];
    if (colum_array_0.length < 2) {
        log.log_error(`sheet_item colum is smaller than two!`);
        return "";
    }

    let content = `export interface ${M.getRowClassName(file_name)}_base\n`;
    content += "{\n";

    for (let i = 0; i < colum_array_0.length; ++i) {
        let data_type = colum_array_1[i];
        content += `\t ${colum_array_0[i]}:${data_type};\n`;
    }
    content += "}\n\n";
    return content;
}

//获取行的类对象
M.get_row_class = function(file_name, sheet_item) {
    let row_array = sheet_item["data"];
    if (!row_array) {
        log.log_error(`get sheet_item['data'] error!`);
        return "";
    }
    if (row_array.length < 4) {
        log.log_error(`sheet_item row_array.length is smaller than four!`);
        return "";
    }
    let colum_array_0 = row_array[0];
    let colum_array_1 = row_array[1];
    if (colum_array_0.length < 2) {
        log.log_error(`sheet_item colum is smaller than two!`);
        return "";
    }

    let construct_param = "";
    for (let i = 0; i < colum_array_0.length && i < colum_array_1.length; ++i) {
        let data_type = colum_array_1[i];
        construct_param += `${colum_array_0[i]}:${data_type}`;
        if (i != colum_array_0.length - 1) {
            construct_param += ",";
        }
    }

    let item_class_content = `export class ${M.getRowClassName(file_name)}\n`;
    item_class_content += "{\n";

    for (let i = 0; i < colum_array_0.length; ++i) {
        let data_type = colum_array_1[i];
        item_class_content += `\tpublic ${colum_array_0[i]}:${data_type};\n`;
    }

    item_class_content += `\tconstructor(${construct_param})\n`;
    item_class_content += "\t{\n"
    for (let i = 0; i < colum_array_0.length; ++i) {
        item_class_content += `\t\tthis.${colum_array_0[i]} = ${colum_array_0[i]};\n`;
    }
    item_class_content += "\t}\n";
    if (file_name == `${lang_file_name}`) {
        item_class_content += lang_fun_content;
    }
    item_class_content += "\n}\n\n";
    return item_class_content;
}

M.get_export_default_class = function(file_name, sheet_item) {
    let row_array = sheet_item["data"];
    let item_class = `${M.getRowClassName(file_name)}`;


    let content = `export default class ${file_name}\n`;
    content += "{\n";
    if (row_array.length < 4) {
        log.log_error(`${file_name} is not avaliable!`);
        return "";
    }
    if (row_array[0].length < 2) {
        log.log_error(`${file_name} is not avaliable!`);
        return "";
    }
    if (colum_type.isStringType(row_array[1][0]) == false) {
        return "";
    }
    let colum_item_0 = row_array[1]
    let param_count = colum_item_0.length;
    for (let i = 3; i < row_array.length; ++i) {
        let colum_item_i = row_array[i];
        if (colum_item_i.length == 0) {
            continue;
        }
        let param_content = "";
        let param_array = colum_item_i;

        for (let j = 0; j < param_count; ++j) {
            if (colum_item_0[j] == "string") {
                if (param_array[j]) {
                    param_content += "`" + param_array[j] + "`";
                } else {
                    if (param_array[j] == 0) {
                        param_content += "`0`";
                    } else {
                        param_content += "``";
                    }

                }
            } else {
                if (param_array[j]) {
                    param_content += `${param_array[j]}`;
                } else {
                    param_content += 0;
                }

            }
            if (j != param_count - 1) {
                param_content += ",";
            }
        }
        if (!colum_item_i[0]) {
            continue;
        }
        content += `\tpublic static ${colum_item_i[0]}:${item_class} = new ${item_class}(${param_content});\n`
    }

    content += "}\n\n";
    return content;
}

M.get_key_value = function(write_file_path, sheet_item) {
    let file_name = utils.get_file_name_no_extname(write_file_path);

    let file_content = `${ts_head}\n`;
    file_content += `export default class ${file_name}\n`;
    file_content += "{\n\n";


    let row_array = sheet_item["data"];
    if (row_array.length < 4) {
        log.log_error(`wirte_map_sheet ${write_file_path} failed!`);
        return;
    }
    for (let i = 3; i < row_array.length; ++i) {
        let colum_array = row_array[i];
        if (colum_array < 4) {
            log.log_error(`wirte_map_sheet ${write_file_path} the row ${i} is error!`);
            return;
        }
        let colum_str = M.get_key_value_item_string(colum_array);
        if (colum_str == null) {
            return;
        }
        file_content += colum_str;
    }
    file_content += "}";

    return file_content;
}
M.get_key_value_item_string = function(colum_array) {
    // 0 key 1 value 2 type 3 desc
    let key = colum_array[0];
    let value = colum_array[1];
    let type = colum_array[2];
    let desc = colum_array[3] || "``";
    if (key == "") {
        log.log_error(`write_key_value ${write_file_path} the key is error`);
        return null;
    }
    if (type == "") {
        log.log_error(`write_key_value ${write_file_path} the type is error`);
        return null;
    }

    let content = `\t//${desc}\n`;

    if (type == "string") {
        let str = value ? ("`" + value + "`") : "``";
        content += `\tpublic static ${key} : ${type} = ${str};\n\n`;
    } else {
        content += `\tpublic static ${key} : ${type} = ${value};\n\n`;
    }

    return content;
}



M.get_export_string_array = function(file_name, sheet_item) {
    let content = "";
    let data_array = sheet_item.data;
    let array_name = M.getArrayName(file_name);
    for (let i = 3; i < data_array.length; ++i) {
        content += `${array_name}_array.push(${file_name}.${data_array[i][0]});\n`;
    }
    return content;
}

M.get_export_number_array = function(file_name, sheet_item) {
    let array_name = M.getArrayName(file_name);
    let item_class = `${M.getRowClassName(file_name)}`;
    let content = "";
    let row_array = sheet_item["data"];
    let colum_item_0 = row_array[1]
    let param_count = colum_item_0.length;
    for (let i = 3; i < row_array.length; ++i) {
        let colum_item_i = row_array[i];
        let param_content = "";
        let param_array = colum_item_i;

        for (let j = 0; j < param_count; ++j) {
            if (colum_item_0[j] == "string") {
                if (param_array[j]) {
                    param_content += "`" + param_array[j] + "`";
                } else {
                    param_content += "``";
                }
            } else {
                if (param_array[j]) {
                    param_content += `${param_array[j]}`;
                } else {
                    param_content += 0;
                }

            }
            if (j != param_count - 1) {
                param_content += ",";
            }
        }
        if (null == colum_item_i[0]) {
            continue;
        }
        content += `${array_name}_array.push(new ${item_class}(${param_content}));\n`
    }

    return content;
}


M.getArrayName = function(file_name) {
    return `${file_name}`;
}
M.get_export_array = function(file_name, sheet_item) {
    let row_array = sheet_item["data"];
    let item_class = `${M.getRowClassName(file_name)}`;

    if (row_array.length < 4) {
        log.log_error(`${file_name} is not avaliable!`);
        return "";
    }
    if (row_array[0].length < 2) {
        log.log_error(`${file_name} is not avaliable!`);
        return "";
    }
    let content = `export let ${M.getArrayName(file_name)}_array:${item_class}[] = [];\n`;
    if (colum_type.isStringType(row_array[1][0])) {
        content += M.get_export_string_array(file_name, sheet_item);
    } else {
        content += M.get_export_number_array(file_name, sheet_item);
    }

    return content;
}


M.get_enum_item = function(colum_array) {
    // 0 key 1 value 2 type 3 desc
    let key = colum_array[0];
    let value = colum_array[1];
    let type = colum_array[2];
    let desc = colum_array[3] || "``";
    if (key == "") {
        log.log_error(`write_key_value ${write_file_path} the key is error`);
        return "";
    }
    if (type == "") {
        log.log_error(`write_key_value ${write_file_path} the type is error`);
        return "";
    }

    let content = `\t//${desc}\n`;
    if (type == "string") {
        let str = value ? ("`" + value + "`") : "``";
        content += `\t${key} = ${str},\n\n`;
    } else {
        content += `\t${key} = ${value},\n\n`;
    }
    return content;
}

M.get_enum = function(file_name, sheet_item) {

    let file_content = `${ts_head}\n`;
    file_content += `enum ${file_name}\n`;
    file_content += "{\n\n";


    let row_array = sheet_item["data"];
    if (row_array.length < 4) {
        log.log_error(`wirte_map_sheet ${write_file_path} failed!`);
        return "";
    }
    for (let i = 3; i < row_array.length; ++i) {
        let colum_array = row_array[i];
        if (colum_array < 4) {
            log.log_error(`wirte_map_sheet ${write_file_path} the row ${i} is error!`);
            return "";
        }
        let colum_str = M.get_enum_item(colum_array);
        if (colum_str == null) {
            return "";
        }
        file_content += colum_str;
    }
    file_content += "}\n\n";
    file_content += `export default  ${file_name}`;
    return file_content;
}

M.getDictionaryHeadFile = function(write_file_path) {

    let project = require("./../../project")
    let dictionary_ts_path = project.game_dictionary_ts_path;
    let content = `${ts_head}\n`;
    let from = path.dirname(write_file_path);
    let to = path.dirname(dictionary_ts_path)
    let dictionary_relative_path = path.relative(from, to);
    dictionary_relative_path = "../" + utils.replace_path_to_unix_path(dictionary_relative_path);
    content += `import Dictionary from "${dictionary_relative_path}/Dictionary";\n\n`;
    return content;
}

M.getDictContent = function(file_name, sheet_item) {
    let colum = M.getIndexColum(sheet_item);
    let variable_name = `${file_name}_dict`;
    let content = `export let ${variable_name}:Dictionary<${M.getRowClassName(file_name)}> = new Dictionary<${M.getRowClassName(file_name)}>();\n`;
    let data_array = sheet_item.data;

    let is_number = colum_type.isNumberType(data_array[1][colum]);
    for (let i = 3; i < data_array.length; ++i) {
        if (data_array[i].length == 0) {
            continue;
        }
        let param1 = is_number ? data_array[i][colum] : `"${data_array[i][colum]}"`;
        let param2 = `${file_name}.${data_array[i][0]}`;
        content += `${variable_name}.setObject(${param1},${param2});\n`;
    }
    content += "\n";
    return content;
}

M.getMulArrContent = function(file_name, sheet_item) {
    let variable_name = `${file_name}`;
    let content = `export let ${variable_name}_mul_arr:Array<${M.getRowClassName(file_name)}[]> = new Array<${M.getRowClassName(file_name)}[]>();\n`;
    let sheet_data_array = sheet_item.data;


    let list_array = {};
    for (let i = 3; i < sheet_data_array.length; ++i) {
        if (sheet_data_array[i].length == 0) {
            continue;
        }
        let item = sheet_data_array[i];
        if (!list_array[item[0]]) {
            list_array[item[0]] = [];
        }
        list_array[item[0]].push(item);
    }
    for (let key in list_array) {
        let tmp = M.getMulDictContenParams(file_name, sheet_data_array, list_array[key])
        content += `${variable_name}_mul_arr.push([${tmp}]);\n`;
    }

    content += "\n";
    return content;
}

M.getMulDictContent = function(file_name, sheet_item) {

    let variable_name = `${file_name}_dict`;
    let content = `export let ${variable_name}:Dictionary<${M.getRowClassName(file_name)}[]> = new Dictionary<${M.getRowClassName(file_name)}[]>();\n`;
    let sheet_data_array = sheet_item.data;


    let list_array = {};
    for (let i = 3; i < sheet_data_array.length; ++i) {
        if (sheet_data_array[i].length == 0) {
            continue;
        }
        let item = sheet_data_array[i];
        if (!list_array[item[0]]) {
            list_array[item[0]] = [];
        }
        list_array[item[0]].push(item);
    }
    for (let key in list_array) {
        let tmp = M.getMulDictContenParams(file_name, sheet_data_array, list_array[key])
        content += `${variable_name}.setObject(${key},[${tmp}]);\n`;
    }

    content += "\n";
    return content;
}
M.getMulDictContenParams = function(file_name, sheet_data_array, param_array) {
    let content = "";
    for (let i = 0; i < param_array.length; ++i) {
        content += M.getMulDictContenParamsHelp(file_name, sheet_data_array, param_array[i]);
        if (i < param_array.length - 1) {
            content += ",";
        }
    }
    return content;
}

M.getMulDictContenParamsHelp = function(file_name, sheet_data_array, item) {
    let content = `new ${file_name}_item(`;
    for (let i = 0; i < sheet_data_array[1].length; ++i) {
        let is_number = colum_type.isNumberType(sheet_data_array[1][i]);
        if (is_number) {
            if (!item[i]) {
                content += "0";
            } else {
                content += `${item[i]}`
            }
        } else {
            if (!item[i]) {
                content += `""`;
            } else {
                content += `"${item[i]}"`;
            }
        }
        if (i < sheet_data_array[1].length - 1) {
            content += ",";
        }
    }
    content += ")"
    return content;
}


M.getTableName = function(file_name) {
    let content = `export const ${file_name}_table_name :string = "${file_name}";\n`;
    return content;
}

M.getMountTableToWindow = function(file_name) {
    let content = "";
    content = `window["table"] = window["table"] || {};
window["table"][${file_name}_table_name] =   ${file_name};



`
    return content;
}

M.getMountArrayTableToWindow = function(file_name) {
    let content = "";
    content = `window["table"] = window["table"] || {};
window["table"][${file_name}_table_name] =   ${file_name}_array;



`
    return content;
}

M.getMulArrName = function(sheet_name) {
    let content = `export const ${sheet_name}_mul_arr_name :string = "${sheet_name}_mul_arr";\n`;
    return content;
}
M.getMountArrayToWindow = function(file_name) {
    let content = "";
    content = `window["arr"] = window["arr"] || {};
window["arr"][${file_name}_mul_arr_name] = ${file_name}_mul_arr; 



`;
    return content;
}

M.getDictName = function(file_name) {
    let content = `export const ${file_name}_dict_name :string = "${file_name}_dict";\n`;
    return content;
}

M.getMountDictToWindow = function(file_name) {
    let content = "";
    content = `window["dict"] = window["dict"] || {};
window["dict"][${file_name}_dict_name] = ${file_name}_dict; 



`;

    return content;
}


M.getCommonLangItems = function(sheet_item) {
    let content = "";
    let parmas = "";
    let data_array = sheet_item.data;
    for (let i = 3; i < data_array.length; ++i) {
       
        parmas = "";
        for(let j = 0;j < data_array[i].length;++j)
        {
            parmas += `\`${data_array[i][j]}\``;
            if(j < data_array[i].length - 1)
            {
                parmas += ",";
            }
        }
        content += `lang[\`${data_array[i][0]}\`]  = new lang_item(${parmas});\n\n`;
    }
    return content;
}
module.exports = M;