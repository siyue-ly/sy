let xlsl_util = require("./xlsl_util");

let M = {};

M.parse = function(file_name,sheet_item,write_dir_path)
{
    let str = "";
    str += xlsl_util.get_enum(file_name,sheet_item);
    return str;
}

module.exports = M;