
let xlsl_util = require("./xlsl_util");

let M = {};

M.parse = function(file_name,sheet_item,write_dir_path)
{
    let str = "";
    str += xlsl_util.getPrimaryEnum(sheet_item);
    str += xlsl_util.get_row_interface(file_name,sheet_item);
    str += xlsl_util.get_row_class(file_name,sheet_item);
    str += xlsl_util.get_export_default_class(file_name,sheet_item);
    str += xlsl_util.getTableName(file_name);
    str += xlsl_util.getMountTableToWindow(file_name);
    return str;
}

module.exports = M;