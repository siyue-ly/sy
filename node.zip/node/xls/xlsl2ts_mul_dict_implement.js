
let xlsl_util = require("./xlsl_util");
let log = require("./../utils/log");

let M = {};

M.parse = function(file_name,sheet_item,write_dir_path)
{
    let str = "";
    str += xlsl_util.getDictionaryHeadFile(write_dir_path);
    str += xlsl_util.get_row_interface(file_name,sheet_item);
    str += xlsl_util.get_row_class(file_name,sheet_item);
    str += xlsl_util.getMulDictContent(file_name,sheet_item);
    str += xlsl_util.getDictName(file_name);
    str += xlsl_util.getMountDictToWindow(file_name);
    return str;
}

module.exports = M;