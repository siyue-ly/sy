let M = {};

let xlsl_util = require("./xlsl_util");

M.parse = function(file_name,sheet_item,write_dir_path)
{
    return xlsl_util.get_key_value(file_name,sheet_item);
}

module.exports = M;