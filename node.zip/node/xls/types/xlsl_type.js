let M = {};

// key value 键值对的类型

M.isKeyValueType = function(str)
{
    return str == "key_value";
}

//普通类型
M.isCommonType = function(str)
{
    return str == "common";
}

//数组类型
M.isArrayType = function(str)
{
    return str == "array";
}

M.isEnumType = function(str)
{
    return str == "enum";
}

M.isDictionType = function(str)
{
    return str == "dict";
}

M.isMulDictionType = function(str)
{
    return str == "mul_dict";
}

M.isMulArrayType = function(str)
{
    return str == "mul_arr";
}

M.isCommonLnagType = function(str)
{
    return str == "common_lang";
}

module.exports = M;