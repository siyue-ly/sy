let M = {};


M.isStringType = function(str)
{
    return str  == "string";
}

M.isNumberType = function(str)
{
    return str == "number";
}



module.exports = M;