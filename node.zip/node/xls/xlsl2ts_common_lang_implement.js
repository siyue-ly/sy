let xlsl_util = require("./xlsl_util");

let M = {};

M.parse = function(file_name,sheet_item,write_dir_path)
{
    let str = `import lang, { lang_item } from "./lang_xlsx";\n\n`;

    str += xlsl_util.getPrimaryEnum(sheet_item);
  
    str += xlsl_util.getCommonLangItems(sheet_item);
    
    return str;
}

module.exports = M;