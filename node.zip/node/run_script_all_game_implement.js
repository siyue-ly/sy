
let log = require("./utils/log");
let utils = require("./utils/utils");
let path = require("path");
let process = require("process");

let M = {};
M.script_root = "";

M.exclude_game_type_dir = ["client_dev_tools", "client_pack_tools", "newfish_vg", "SLOTSLIVE", "MiniGameLive"];

M.exclude_game_dir = ["00.tools"];

M.exe_script = function(script, game_type, game_dir, chnanel, pack_type)
{
    let cmd = `node ${script} ${game_type} ${game_dir} ${chnanel} ${pack_type}`;
    utils.exec(cmd);
}

M.get_pack_map_data = function()
{
    let pack_map_data = {};
    let all_game_root = path.join(M.script_root, "..")
    let game_types = utils.list_dir_no_rescusion(all_game_root);
    for(let i = 0;i < game_types.length; ++i)
    {
        if(M.exclude_game_type_dir.includes(game_types[i]))
            continue;
        pack_map_data [game_types[i]] = pack_map_data [game_types[i]] || [];
        let games = utils.list_dir_no_rescusion(path.join(all_game_root, game_types[i]));
        for(let j = 0; j < games.length; ++j)
        {
            if(M.exclude_game_dir.includes(games[j]))
                continue;
            pack_map_data [game_types[i]].push(games[j]);
        }
    }
    return pack_map_data;
}

M.doit = function(script, channel, pack_type)
{
    let pack_map_data = M.get_pack_map_data();

    let total_games = 0;
    for(let game_type in pack_map_data)
    {
        total_games += pack_map_data[game_type].length;
    }
    let running_games = 0;
    for(let game_type in pack_map_data)
    {
        for(let i = 0;i < pack_map_data[game_type].length; ++i)
        {
            running_games += 1;
            M.setTitle(running_games, total_games, game_type, pack_map_data[game_type][i]);
            M.exe_script(script, game_type, pack_map_data[game_type][i], channel, pack_type);
        }
    }
}

M.setTitle = function(running_games, total_games, cur_game_type, game)
{
    process.title = `${running_games}/${total_games} ${cur_game_type} ${game}`;
}
M.execute = function(args, script_root)
{
    M.script_root = script_root;
    let params = args.join(" ");
    log.log_msg(params);
    if(args.length < 3)
        return;
    let script = args[0];
    let channel = args[1];
    let pack_type = args[2];
    M.doit(script, channel, pack_type);
}

module.exports = M;