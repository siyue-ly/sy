let utils = require("./utils/utils");
let log = require("./utils/log");
let path = require("path");
let xlsl2ts_common_implement = require("./xls/xlsl2ts_common_implement");
let xlsl2ts_keyvalue_implements = require("./xls/xlsl2ts_keyvalue_implements");
let xlsl2ts_array_implement = require("./xls/xlsl2ts_array_implement");
let xlsl2ts_enum_implements = require("./xls/xlsl2ts_enum_implements");
let xlsl2ts_dict_implement = require("./xls/xlsl2ts_dict_implement");
let xlsl_type = require("./xls/types/xlsl_type");
let xlsl2ts_mul_dict_implement = require("./xls/xlsl2ts_mul_dict_implement");
let xlsx2ts_mul_arr_implement = require("./xls/xlsx2ts_mul_arr_implement");
let xlsl2ts_common_lang_implement = require("./xls/xlsl2ts_common_lang_implement");

let exclude_files = [];

let M = {};
M.publish_project_scripts_root = "";
M.module_name = null;

M.write_sheet = function(write_dir_path, file_name_no_extern, content) {
    let file_url = path.join(write_dir_path, `${file_name_no_extern}_xlsx.ts`);
    utils.writeFileSync(file_url, content);
}

M.isExcludeFile = function(file_name) {
    let num = 0;
    for (num = 0; num < exclude_files.length; ++num) {
        if (exclude_files[num] == file_name) {
            return true;
        }
    }
    return false;
}

M.getParseImplements = function(sheet_name) {
    if (xlsl_type.isCommonType(sheet_name)) {
        return xlsl2ts_common_implement;
    } else if (xlsl_type.isKeyValueType(sheet_name)) {
        return xlsl2ts_keyvalue_implements;
    } else if (xlsl_type.isArrayType(sheet_name)) {
        return xlsl2ts_array_implement;
    } else if (xlsl_type.isEnumType(sheet_name)) {
        return xlsl2ts_enum_implements;
    } else if (xlsl_type.isDictionType(sheet_name)) {
        return xlsl2ts_dict_implement;
    } else if (xlsl_type.isMulDictionType(sheet_name)) {
        return xlsl2ts_mul_dict_implement;
    } else if (xlsl_type.isMulArrayType(sheet_name)) {
        return xlsx2ts_mul_arr_implement;
    }
    else if(xlsl_type.isCommonLnagType(sheet_name)){
        return xlsl2ts_common_lang_implement;
    }
    return null;
}

M.generate_ts_item = function(item) {
    let src_file_path = item.file_path;
    if (utils.isTempFile(src_file_path)) {
        return;
    }

    let write_dir_path = path.join(M.publish_project_scripts_root, item.relative_path);

    let sheets_array = utils.read_xlsx(src_file_path);
    if (!sheets_array) {
        log.log_error(`parse ${src_file_path} failed!`);
        return;
    }
    let file_name_no_extname = utils.get_file_name_no_extname(item.file_path);
    for (let key in sheets_array) {
        let item = sheets_array[key];
        let parseObject = M.getParseImplements(item.name);
        if (!parseObject) {
            log.log_error(`sheet name ${item.name} error!`);
            continue;
        }
        let content = parseObject.parse(file_name_no_extname, item, write_dir_path);
        M.write_sheet(write_dir_path, file_name_no_extname, content);
    }
}

M.generate_ts = function(search_dir) {
    let files_item_array = utils.recursion_list_all_files(search_dir, ".xlsx");
    if (!files_item_array) {
        log.log_error(`${config_game_root} is not exits `);
        return;
    }
    for (let i = 0; i < files_item_array.length; ++i) {

        if (M.isExcludeFile(files_item_array[i].base_name)) {
            continue;
        }
        if (this.module_name == null) {
            M.generate_ts_item(files_item_array[i]);
        } else {
            if (this.module_name == M.getModuleName(files_item_array[i])) {
                M.generate_ts_item(files_item_array[i]);
            }
        }
    }
}

M.getModuleName = function(item) {
    let relative_path = item.relative_path;
    let module1 = relative_path.substr("modules/".length);
    let index = module1.indexOf("/");
    if (index == -1) return "";
    let module_name = module1.substr(0, index);
    return module_name;
}

M.export_xlsx = function()
{
    M.publish_project_scripts_root = M.project.game_scripts_root;

    let common_path  = path.join(M.project.tool_root,"sdk","resources","config");
    let common_channel_path = path.join(M.project.tool_root,"channel", M.project.game_channel_name ,"resources","config");

    let game_type_path = path.join(M.project.game_type_root, "00.tools", "sdk", "resources","config");
    let game_type_channel_path = path.join(M.project.game_type_root, "00.tools", "channel", M.project.game_channel_name, "resources","config");

    let game_path =  path.join(M.project.game_root,  "resources","config");
    let game_channel_path =  path.join(M.project.game_root,  "channel", M.project.game_channel_name, "resources","config");


    let xlsx_path_array = [common_path, common_channel_path, game_type_path, game_type_channel_path, game_path, game_channel_path];
    for(let i = 0;i < xlsx_path_array.length ;++i)
    {
        if(!utils.is_file_exists(xlsx_path_array[i]))
        {
            continue;
        }
        log.log_msg(`导出xlsx:${xlsx_path_array[i]}`);
        M.generate_ts(xlsx_path_array[i]);
    }
}



M.execute = function(project) 
{
    M.project = project;

    M.check_common_lang_conflict_with_game(project);

    M.export_xlsx();
}

//检查语言包重复
M.check_common_lang_conflict_with_game = function(project)
{
    let commom_lang_path = path.join(project.tool_root,"sdk","resources","config","modules","common","config","common_lang.xlsx");
    let game_lang_path = path.join(project.game_config_root,"modules","common","config","lang.xlsx");
    log.log_msg(`检查冲突语言包:\n${commom_lang_path}\n${game_lang_path}`);

    if(!utils.is_file_exists(commom_lang_path)){

        log.log_error(`文件不存在:${commom_lang_path}`);
        process.exit(0);
    }
    if(!utils.is_file_exists(game_lang_path)){
        log.log_error(`文件不存在:${game_lang_path}`);
        process.exit(0);
    }

    let common_lang_array = utils.read_xlsx(commom_lang_path)[0]["data"];
    let game_lang_array = utils.read_xlsx(game_lang_path)[0]["data"];

    let common_lang_map = {};
    let game_lang_map = {};

    let key = "";
    for(let i = 3;i < common_lang_array.length;++i)
    {
        key = common_lang_array[i][0];
        if(common_lang_map[key])
        {
            log.log_error(`通用语言包重复,重复ID:${key}`);
            log.log_error(`修改1个文件:${commom_lang_path}`);
            process.exit(0);
        }
        common_lang_map[key] = key;
    }


    for(let i = 3;i < game_lang_array.length;++i)
    {
        key = game_lang_array[i][0];
        if(game_lang_map[key])
        {
            log.log_error(`游戏语言包重复,重复ID:${key}`);
            log.log_error(`修改1个文件:${game_lang_path}`);
            process.exit(0);
        }
        game_lang_map[key] = key;
    }

    for(let key in common_lang_map)
    {
        if(game_lang_map[key])
        {
            log.log_error(`游戏语言包重复,重复ID:${key}`);
            log.log_error(`修改2个文件:\n${commom_lang_path}\n${game_lang_path}`);
            process.exit(0);
        }
    }
}
module.exports = M;