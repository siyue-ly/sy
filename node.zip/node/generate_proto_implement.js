let path = require("path");
let utils = require("./utils/utils");
let log = require("./utils/log");

let M = {}

M.generate_proto_js_ts = function(protos_path,src_proto,dst_ts_dir)
{
    let ts_cmd = `npx protoc --ts_out ${dst_ts_dir} --proto_path ${protos_path} ${src_proto}`;
    utils.exec(ts_cmd);
    log.log_msg(`make ${dst_ts_dir} ok`);
}

M.generate_proto_item = function(protos_path,item)
{
    let src_file_path = item.file_path;
    let dst_file_dir = path.join(M.project_root,"assets","scripts");
    M.generate_proto_js_ts(protos_path,src_file_path,dst_file_dir);
}

M.generate_proto = function(proto_root)
{
    let proto_game_root = path.join(proto_root,"modules");
    let files_item_array = utils.recursion_list_all_files(proto_game_root,".proto");
    if(!files_item_array)
    {
        log.log_error(`${proto_game_root} is not exits protos`);
        return;
    }
    for(let i = 0;i < files_item_array.length;++i)
    {
        M.generate_proto_item(proto_root,files_item_array[i]);
    }
}
M.execute = function(project)
{
    M.project_root = project.game_root;
    M.generate_proto(project.common_proto_root);
    M.generate_proto(project.game_type_proto_root);
    M.generate_proto(project.game_proto_root);
}
module.exports = M;