let http = require("http");
let shelljs = require("shelljs");
let path = require("path")
const { log_error, log_msg } = require("./utils/log");


//泰语
//const lang = "th"
//繁体中文
//zh_tw
//越南语
const lang = "zh_cn";

let M = {};
M.vscode_url = "";


M.rerwite_vscode_config = function(url) {
  
    let file = "launch.json";
    shelljs.cd(M.vscode_root);
    let content = ` "url": "${url}",`;
    shelljs.sed('-i', /.*localhost.*/, content, file);
}

M.build_token = function() {

    console.log(`token_url: ${this.request_token_url}`);
    http.get(this.request_token_url, function(res) {
        res.on("data", function(data) {
            var dataStr = data.toString("utf-8")
            var data_obj = JSON.parse(dataStr);
            if (data_obj["token"]) {
                let token = data_obj["token"];
                //老的显示方式
                //let vs_code_url = `http://localhost:7456?token=${token}&lang=${lang}&goldrate=0.01&goldformat=0`;
                //金币的 K,M....显示方式
                let vs_code_url = `http://localhost:7456?token=${token}&lang=${lang}&goldrate=0.01&goldformat=0&five_star=1&cdn_cfg=${M.cdn_config}`;
                M.rerwite_vscode_config(vs_code_url);
                log_msg(`rewrite ${token} ok`);
            } else {
                console.error("server data error no token field");
            }
        });
    });
}

M.execute = function(request_token_url,vscode_root,cdn_config) {
    M.request_token_url = request_token_url;
    M.vscode_root = vscode_root;
    M.cdn_config = cdn_config;
    M.build_token();
}

module.exports = M;