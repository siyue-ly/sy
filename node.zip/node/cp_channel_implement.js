let shell = require("shelljs");
let path = require("path");
let utils = require("./utils/utils");
let process = require("process");
let log = require("./utils/log");


let M = {};
M.project = null;

//打包模板
M.MakeBuildTemplates = function() 
{
    let game_buildtemplates_path = path.join(M.project.game_root, "build-templates");
    let web_mobile_path = path.join(game_buildtemplates_path, "web-mobile");
    let target_path =  path.join(M.project.tool_root, "build-templates","template", "web-mobile");
    let html_path = path.join(web_mobile_path,"index.html");

   
    if(utils.is_file_exists(target_path) == false)
    {
        console.log(`打包模板不存在:${target_path}`);
        process.exit(0);
    }
    if(utils.is_file_exists(game_buildtemplates_path) == false)
    {
        shell.mkdir(game_buildtemplates_path);
    }
    shell.rm("-rf",web_mobile_path);
    shell.mkdir(web_mobile_path);
    //拷贝模板
    let files = utils.recursion_list_all_files(target_path);
    for (let i = 0; i < files.length; ++i) {
        shell.cp("-f", files[i].file_path, web_mobile_path);
    }

    //html 修剪
    let orientation = M.project.game_orientation;
    if(orientation == "auto")
    {
        orientation = "portrait";
    }
    //替换横竖屏
    if(orientation == "landscape")
    {
        let portrait1 = `\t<meta name="screen-orientation" content="landscape"/>`
        let portrait2 = `\t<meta name="x5-orientation" content="landscape">`
        shell.sed("-i", /.*screen-orientation.*/, portrait1, html_path);
        shell.sed("-i", /.*x5-orientation.*/, portrait2, html_path);
    }

    //替换引擎脚本
    let CustomeEngineFile = path.join(M.project.game_root, "CustomEngineModule.txt");
    let isCustome =  utils.is_file_exists(CustomeEngineFile)
    let common_cocos_engine = `\tlet script = debug ? "../public/cocos-debug-v1.js" : "../public/cocos-release-v1.js";`
    let custom_cocos_engine = `\tlet script = debug ? "./cocos2d-js.js" :  "./cocos2d-js-min.js";`

    let cocos_engine = isCustome ? custom_cocos_engine : common_cocos_engine;
    shell.sed("-i", /.*cocos-debug-v1.js.*/, cocos_engine,html_path);
}

M.copyChannelResHelp = function(src_dir_root,dst_dir_root)
{
    let isCopied = false;
    let files_array = utils.recursion_list_all_files(src_dir_root);
    for(let i = 0;i < files_array.length;++i)
    {
        let item = files_array[i];
        let copy_src_path = path.join(item.absolute_path,item.base_name)
        let copy_dst_path = path.join(dst_dir_root,item.relative_path,item.base_name);
        let dir_name = path.dirname(copy_dst_path);
        if(utils.is_file_exists(dir_name) == false)
        {
            console.log(`目标路径不存在:${dir_name}`);
            console.log(`*****检查路径*****`);
            process.exit(0);
        }
        shell.cp("-f", copy_src_path, copy_dst_path);
        log.log_msg(`拷贝差异文件\nfrom:${copy_src_path}`);
        log.log_msg(`  to:${copy_dst_path}`);
        isCopied = true;
    }
    return isCopied;
}

//拷贝游戏内渠道资源
M.copyGameChannelResToAssets = function()
{
    let src_dir_root = path.join(M.project.game_root,"channel",M.project.game_channel_name,"assets");
    let dst_dir_root = path.join(M.project.game_root,"assets");
    if(utils.is_file_exists(dst_dir_root) == false)
    {
        log.log_error(`项目资源目录不存在:${dst_dir_root}`);
        process.exit(0);
    }
    if(utils.is_file_exists(src_dir_root) == false)
        return;
    M.copyChannelResHelp(src_dir_root,dst_dir_root);
}




//拷贝公用sdk
M.copyCommonSDKToAssets = function()
{
    let src_dir_root = path.join(M.project.tool_root,"sdk","assets");
    let dst_dir_root = path.join(M.project.game_root,"assets");
    if(utils.is_file_exists(dst_dir_root) == false)
    {
        log.log_error(`项目资源目录不存在:${dst_dir_root}`);
        process.exit(0);
    }
    if(utils.is_file_exists(src_dir_root) == false)
        return;
    M.copyChannelResHelp(src_dir_root,dst_dir_root);
}

//拷贝公用渠道资源
M.copyCommonChannelResToAssets = function()
{
    let src_dir_root = path.join(M.project.tool_root,"channel",M.project.game_channel_name,"assets");
    let dst_dir_root = path.join(M.project.game_root,"assets");
    if(utils.is_file_exists(dst_dir_root) == false)
    {
        log.log_error(`项目资源目录不存在:${dst_dir_root}`);
        process.exit(0);
    }
    if(utils.is_file_exists(src_dir_root) == false)
        return;
    M.copyChannelResHelp(src_dir_root,dst_dir_root);
}


//拷贝游戏类型公用sdk
M.copyGameTypeSDKToAssets = function()
{
    let src_dir_root = path.join(M.project.game_type_root, "00.tools", "sdk", "assets");
    let dst_dir_root = path.join(M.project.game_root,"assets");
    if(utils.is_file_exists(dst_dir_root) == false)
    {
        log.log_error(`项目资源目录不存在:${dst_dir_root}`);
        process.exit(0);
    }
    if(utils.is_file_exists(src_dir_root) == false)
        return;
    M.copyChannelResHelp(src_dir_root,dst_dir_root);
}

//拷贝游戏类型渠道sdk
M.copyGameTypeChannelResToAssets = function()
{
    let src_dir_root = path.join(M.project.game_type_root, "00.tools", "channel",M.project.game_channel_name,"assets");
    let dst_dir_root = path.join(M.project.game_root,"assets");
    if(utils.is_file_exists(dst_dir_root) == false)
    {
        log.log_error(`项目资源目录不存在:${dst_dir_root}`);
        process.exit(0);
    }
    if(utils.is_file_exists(src_dir_root) == false)
        return;
    M.copyChannelResHelp(src_dir_root,dst_dir_root);
}



M.execute = function(project)
{
    M.project = project;
    //--注意拷贝资源优先级
    //01.拷贝公用SDK
    log.log_msg("01.拷贝公用SDK");
    M.copyCommonSDKToAssets();
    //02.拷贝公用渠道资源
    log.log_msg("02.拷贝公用渠道资源");
    M.copyCommonChannelResToAssets();
    //03.拷贝游戏类型公用sdk
    log.log_msg("03.拷贝游戏类型公用sdk");
    M.copyGameTypeSDKToAssets();
    //04.拷贝游戏类型渠道sdk
    log.log_msg("04.拷贝游戏类型渠道sdk");
    M.copyGameTypeChannelResToAssets();
    //05.拷贝游戏内渠道资源
    log.log_msg("05.拷贝游戏内渠道资源");
    M.copyGameChannelResToAssets();
    // 拷贝打包模板
    if(M.project.game_id == 100)
    {

    }
    else
    {
        M.MakeBuildTemplates();
    }
}

module.exports = M;