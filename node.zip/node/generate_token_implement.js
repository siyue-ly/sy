var http = require("http");
const opn = require('opn');



let M = {};
M.token_url = "";
M.navagate_url = ""

M.generate = function()
{
    http.get(M.token_url,function(res)
    {
        res.on("data",function(data)
        {
            console.log(data.toString());
            var dataStr = data.toString("utf-8")
            var data_obj = JSON.parse(dataStr);
            if(data_obj["token"])
            {
                let token = data_obj["token"];
                M.navagate_url = `${M.navagate_url}&token=${token}`;
                opn(M.navagate_url, {app: ['chrome']});
            }
            else
            {
                console.error("server data error no token field");
            }            
        });
    });
}


M.execute = function(token_url,navagate_url)
{  
    M.token_url = token_url;
    M.navagate_url = navagate_url;
    M.generate();
}

module.exports = M;









