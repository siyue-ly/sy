let path = require("path");
let utils = require("./utils/utils");
const { log_error, log_msg } = require("./utils/log");
var imageSize = require("image-size")
var SpriteSmith = require('spritesmith');

let M = {};

M.pack_font = async function()
{
    let resources_fonts = path.join(M.project.game_root, "resources_fonts");

    if(utils.is_file_exists(resources_fonts) == false) return;

    let pngs = utils.recursion_list_all_files(resources_fonts,".png");

    if(!pngs) return;

    if(!pngs.length ) return;
 
    let font_dirs = {};

    for(let i = 0;i < pngs.length; ++i)
    {
        let relative_path = pngs[i].relative_path;
        if(!relative_path) continue;
        let deep_dir_name = utils.get_deep_dir_name(relative_path);
        font_dirs[deep_dir_name] = relative_path;
    }

    for(let key in font_dirs)
    {
        await M.export_font(key,font_dirs[key]);
    }
}

M.readDirPngSync = function(dir)
{
    let image_items = [];
    let array = utils.recursion_list_all_files(dir,".png");
    let height_map = {};
    for(let i = 0;i < array.length; ++i)
    {
        let file_path = array[i].file_path
        var char = path.basename(file_path,'.png');
        let size = imageSize(file_path);
        let item = {
            image: file_path,
            char: char,
            imageWidth: size.width,
            imageHeight: size.height
        };
        image_items.push(item);
        height_map[size.height] = 1;
    }
    if(Object.keys(height_map).length > 1)
    {
        log_error(`${dir}\n每张图片的高度不一样,检查后再继续.`);
        process.exit(0);
    }
    return image_items;
}
M.export_font = async function(font_name,relative_font_atlas_dir)
{
    let index = relative_font_atlas_dir.lastIndexOf("/");
    if(index ==  -1)
    {
        log_msg(`路径有误.${relative_font_atlas_dir}`);
        process.exit(0);
    }
    let export_font_path = path.join(M.project.game_root,relative_font_atlas_dir.substring(0,index)) ;
    if(utils.is_file_exists(export_font_path) == false)
    {
        log_msg(`导出路径不存在:${export_font_path}`);
        process.exit(0);
    }
    let font_atlas_dir = path.join(M.project.game_root,"resources_fonts",relative_font_atlas_dir);
    let image_items = M.readDirPngSync(font_atlas_dir);
    await M.export_font_help(font_name, image_items, export_font_path);
}

M.check_exprot_result =  function(sprites)
{
    return new Promise((success, fail)=>{
        SpriteSmith.run({src: sprites, algorithm: 'left-right'}, function (err, result) {
            if(err)
            {
                console.error(err)
                success(null);
                return;
            }
            success(result);
        });
    });
}

M.export_font_help = async function(font_name,image_items,export_font_path)
{
    if(image_items.length == 0)
        return;
    let font_size = image_items[0].imageHeight;
    let sprites = image_items.map((x)=>x.image);
    let result = await M.check_exprot_result(sprites);
    if(!result)
        return;
    M.write_png(font_name, export_font_path, result);
    M.write_fnt(font_size, font_name, export_font_path, image_items, result);
}
M.write_png = function(font_name, export_font_path, result)
{
    let export_font_url = path.join( export_font_path, `${font_name}.png`);
    utils.writeFileSync(export_font_url, result.image);
}

M.getCharData = function(png_path, image_items, coordinateData) 
{
    let util = require('util');
    let char = null;
    for (let i = 0; i < image_items.length; i++) 
    {
        let item = image_items[i];
        if (item.image === png_path) {
            char = item.char;
            break;
        }
    }
    try
    {
        if (char) 
        {
            if(char.length === 1)
            {
                charId = char.charCodeAt(0);
            }
            else
            {
                charId = parseInt(char);
            }
            let charStr = util.format("char id=%d   x=%d    y=%d     width=%d    height=%d    xoffset=0     yoffset=0     xadvance=%d    page=0  chnl=15\n",
                charId, coordinateData.x, coordinateData.y, coordinateData.width, coordinateData.height, coordinateData.width);
            return charStr;
        } else {
            log_error("没有发现字符");
            return null;
        }
    }
    catch(e)
    {
        log_error("没有发现字符",e);
        process.exit(0);
    }
}

M.write_fnt = function(font_size, font_name, export_font_path, image_items, result)
{
    let util = require('util');
    let infoCfg = `info face=\"微软雅黑\" size=${font_size} bold=0 italic=0 charset=\"\" unicode=1 stretchH=100 smooth=1 aa=1 padding=0,0,0,0 spacing=1,1 outline=0\n`;
    let commonCfg = util.format(`common lineHeight=${font_size} base=26 scaleW=%d scaleH=%d pages=1 packed=0 alphaChnl=1 redChnl=0 greenChnl=0 blueChnl=0\n`,
        result.properties.width, result.properties.height);

    let pageCfg = util.format("page id=0 file=\"%s.png\"\n", font_name);
    // 字符数量配置
    let charsCfg = util.format("chars count=%d\n", image_items.length);
    let charArrCfg = "";
    // 字符串配置
    for(let k in result.coordinates) 
    {
        let itemCharCfg = M.getCharData(k, image_items, result.coordinates[k]);
        if (itemCharCfg) {
            charArrCfg += itemCharCfg;
        } else {
            log_error("该图片没有设置字符: " + k);
            log_error("生成font字体失败!");
            process.exit(0);
        }
    }
    let cfg = infoCfg + commonCfg + pageCfg + charsCfg + charArrCfg;
    let fnt_url = path.join(export_font_path, `${font_name}.fnt`);
    utils.writeFileSync(fnt_url, cfg);
}

M.execute = function(project)
{
    M.project = project;
    M.pack_font();
}

module.exports = M;