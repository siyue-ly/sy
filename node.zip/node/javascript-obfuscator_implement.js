//混淆 javascript 
//参考 https://github.com/javascript-obfuscator/javascript-obfuscator

let project = require("./../project");
let path = require("path");
let shelljs = require("shelljs");
let utils = require("./utils/utils");
let M = {};

M.project_root = null;


M.obfuscator = function()
{
    let jspath = path.join(project.game_root, "build", "web-mobile", "assets", "main", "*.js");
    let files_arrays = shelljs.ls("-l", jspath);
    if(files_arrays.length == 0)
    {
        return;
    }
    utils.obfuscatorJS(files_arrays[0].name, files_arrays[0].name);
}

M.execute = function()
{
    M.obfuscator();
}

module.exports = M;