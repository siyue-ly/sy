//// https://www.npmjs.com/package/node-ssh

let node_ssh = require("node-ssh");
let process = require("process");
const ssh = new node_ssh.NodeSSH();
let utils = require("./utils/utils");
let log = require("./utils/log");
let path = require("path");
let M = {};
M.project = null;
M.ssh_config = null;


M.uploadFile = function()
{
    ssh.connect(M.ssh_config).then(function () 
    {
         console.log(`连接服务器[${M.ssh_config.host}]成功`);
         console.log(M.local_zip_path);
         console.log(M.server_zip_path);
         ssh.putFile(M.local_zip_path , M.server_zip_path).then(function(status) {
            M.execCommand();
        }).catch(err=>{
            log.log_error('文件传输异常:',err);

            process.exit(0);
        });
        
    }).catch(err=>{
        log.log_error('ssh连接失败:',err);
        process.exit(0);
    });
 }

M.execCommand = async function()
{
    let cmd = `rm -rdf ${M.unzip_path} && cd ${M.ssh_config.web_root_path} &&  unzip ${M.project.game_id}.zip && rm -rdf ${M.project.game_id}.zip`;
    ssh.execCommand(cmd).then((result)=>{
        if(!result.stderr)
        {
            log.log_msg(`解压完成:${M.unzip_path}`);
            log.log_msg(`文件上传服务器[${M.ssh_config.host}]成功`);
            ssh.dispose();
        }
        else
        {
            log.log_msg(`执行命令失败: ${cmd}`);
        }
        process.exit(0);
    });

}

M.execute = function(ssh_config, project)
{
    M.ssh_config = ssh_config;
    M.project = project;
    let server_game_dir = `${ssh_config.web_root_path + "/" + M.project.game_id}`;
    
    M.local_zip_path  = path.join(M.project.game_root, `build`, `${M.project.game_id.toString()}.zip`);
    if(utils.is_file_exists( M.local_zip_path) == false)
    {
        log.log_error(`文件不存在: ${M.local_zip_path}`);
        process.exit(0);
    }
    M.server_zip_path = `${server_game_dir}.zip`;
    M.unzip_path = server_game_dir;
    M.uploadFile();
}

module.exports = M;