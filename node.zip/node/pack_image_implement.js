
let path = require("path");
let utils = require("./utils/utils");


let M = {};
M.public_project_dir = "";



M.doCmdNormal = function(sheet_dir, plist_file, pic_file, format) {
    utils.packAtlas(sheet_dir,plist_file,pic_file, format);
}

M.doCmdBigPic = function(src_pic, plist_file, pic_file) {
    utils.compressSinglePic(src_pic, plist_file, pic_file);
}

M.doModuleHelp = function(target_dir, module_name, atlas_dir) {

    if (!utils.is_dir(target_dir)) return;
    let sheet_dirs = utils.list_dir_no_rescusion(target_dir);
    let format = atlas_dir.indexOf("jpg") != -1 ? "jpg" : "png";

    let num = 0;
    let sheet_dir = "";
    let plist_file = "";
    let pic_file = "";
    let child_dir_name = "";
    for (num = 0; num < sheet_dirs.length; ++num) {
        child_dir_name = sheet_dirs[num];
        sheet_dir = path.join(target_dir, child_dir_name);
        plist_file = path.join(M.public_project_dir, "assets", "res", "modules", module_name, "res", atlas_dir, child_dir_name + ".plist");
        pic_file = path.join(M.public_project_dir, "assets", "res", "modules", module_name, "res", atlas_dir, child_dir_name  + `.${format}`);
        M.doCmdNormal(sheet_dir, plist_file, pic_file, format);
    }
}

M.doModule = function(parent_path, module_name) {
    let module_res_root = path.join(parent_path, module_name, "res");
    let dirs = utils.list_dir_no_rescusion(module_res_root);
    for (let num = 0; num < dirs.length; ++num) {
        let target_dir = path.join(module_res_root, dirs[num]);
        M.doModuleHelp(target_dir, module_name, dirs[num]);
    }
}


M.do_big_pic = function(item)
{
    let sheet_dir = item.absolute_path;
    sheet_dir = item.file_path;
    let plist_file = path.join(item.absolute_path, utils.cut_extname(item.base_name) +".plist");
    let pic_file = path.join(M.public_project_dir, "assets", "res", "modules",item.relative_path,item.base_name);
    M.doCmdBigPic(sheet_dir, plist_file, pic_file);
}
M.check_big_pic = function()
{
    let resources_atlas_res_modules = path.join(M.public_project_dir, "resources_big_pic", "res", "modules");
    if(utils.is_file_exists(resources_atlas_res_modules) == false)
        return;
    let arr = utils.recursion_list_all_files(resources_atlas_res_modules,".png");
    for(let i = 0;i < arr.length; ++i)
    {
        M.do_big_pic(arr[i]);
    }
    arr = utils.recursion_list_all_files(resources_atlas_res_modules,".jpg");
    for(let i = 0;i < arr.length; ++i)
    {
        M.do_big_pic(arr[i]);
    }
}


M.execute = function(public_project_dir) {
    M.public_project_dir = public_project_dir;
    let resources_atlas_res_modules = path.join(M.public_project_dir, "resources_atlas", "res", "modules");
    let dirs = utils.list_dir_no_rescusion(resources_atlas_res_modules);
    let num = 0;
    for (num = 0; num < dirs.length; ++num) {
        M.doModule(resources_atlas_res_modules, dirs[num]);
    }
    M.check_big_pic();
}
module.exports = M;