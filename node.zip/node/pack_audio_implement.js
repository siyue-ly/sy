let path = require("path");
let fs = require("fs");
let log = require("./utils/log");
let utils = require("./utils/utils");
let M = {};


M.project = null;
M.public_project_dir = null;



M.doCmdAudio = function(src,dst)
{
    let doPack = false;

    do
    {
        if(utils.is_file_exists(dst) == false)
        {
            doPack = true;
            break;
        }
        if(utils.is_file_exists(src) && utils.is_file_exists(dst))
        {
            //待压缩的目标文件
            let src_stat = fs.statSync(src);
            //工程目录中的文件
            let dst_stat = fs.statSync(dst);
            //有新文件
            if(src_stat.mtimeMs > dst_stat.mtimeMs)
            {
                doPack = true;
                break;
            }
        }
    }while(0);
    if(doPack == false)
    {
        log.log_msg(`${dst} Output files are newer than the input files, nothing to do`);
        return;
    }
    if(utils.is_file_exists(dst))
    {
        fs.rmSync(dst);
    }
    let cmd = utils.getCmdPackAudio(src,dst);
    utils.exec(cmd);
}

M.do_big_audio = function(item)
{
    let src = item.file_path;
    let dst_dir = path.join(M.public_project_dir,"assets","res","modules",item.relative_path);
    if(utils.is_file_exists(dst_dir) == false)
    {
        log.log_msg(`目标路径不存在:${dst_dir}`);
        process.exit(0);
    }
    let dst = path.join(dst_dir,item.base_name);
    M.doCmdAudio(src,dst);
}

M.pack_audio = function()
{
    let resources_atlas_res_modules = path.join(M.public_project_dir, "resources_audio", "res", "modules");
    let arr = utils.recursion_list_all_files(resources_atlas_res_modules,".mp3");
    if(!utils.is_file_exists(resources_atlas_res_modules))
    {
        log.log_error(`目录不存在:${resources_atlas_res_modules}`);
        return;
    }
    for(let i = 0;i < arr.length; ++i)
    {
        M.do_big_audio(arr[i]);
    }
    arr = utils.recursion_list_all_files(resources_atlas_res_modules,".wav");
    for(let i = 0;i < arr.length; ++i)
    {
        M.do_big_audio(arr[i]);
    }
}

M.execute = function(project)
{
    M.project = project;
    M.public_project_dir = M.project.game_root;
    M.pack_audio();
}

module.exports = M;