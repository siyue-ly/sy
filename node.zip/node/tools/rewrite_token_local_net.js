let os = require("os");
let project = require("./project");
let rewrite_vs_token_implement = require("./node/rewrite_vs_token_implement");
let hostname = os.hostname();
let request_token_url = "";
let cdn_config = "";


request_token_url = `http://192.168.18.133:10027/api/testLogin?userName=zzzd&balance=10&agentName=gttest`;

cdn_config = "http://192.168.18.133:11003/public/myconfig.txt";

rewrite_vs_token_implement.execute(request_token_url, project.vscode_root, cdn_config);