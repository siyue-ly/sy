let path = require("path");
let project = require("./project");
let cp_channel_implement = require("./node/cp_channel_implement");
let make_svn_version_implement = require("./node/make_svn_version_implement");


00.svn更新tool_root
make_svn_version_implement.execute(project.tool_root);
//01.svn更新game_type_root
make_svn_version_implement.execute(project.game_type_root);

//1.拷贝资源
cp_channel_implement.execute(project);
