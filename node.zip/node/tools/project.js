let path = require("path");
let process = require("process");
let utils = require("./node/utils/utils");


let tool_root = __dirname;


//游戏类型目录(也就是游戏根目录的父目录)
let game_type_root = "";
//游戏根目录
let game_root = "";
//发布渠道
let game_channel_root = "";
//发布渠道名
let game_channel_name = "default";
//游戏id
let game_id = "";
//是否是竖屏游戏
let game_orientation = "portrait";


let is_debug = false;

// process.argv[2] = "MiniGame";    //游戏类型文件夹
// process.argv[3] = "skydiving";     //游戏文件夹
// process.argv[4] = "default";     //渠道名称
// process.argv[5] = is_debug;      //打包类型

let M = {};

console.log(process.argv)

function checkArgs()
{
    if(process.argv.length < 6)
    {
        console.log("命令使用错误.")
        console.log(`node script.js balloon default[swg] debug[release]`);
        process.exit(0);
    }
}

//检查游戏工程路径
function checkGameDir()
{
    game_root = path.join(tool_root,"../", process.argv[2], process.argv[3]);
    game_type_root = path.join(tool_root,"../", process.argv[2]);
    if(utils.is_file_exists(game_root) == false)
    {
        console.log(`工程不存在:${game_root}`);
        process.exit();
    }
}

//游戏内检查渠道
function checkChannel()
{
    game_channel_name = process.argv[4];
    game_channel_root = path.join(game_root,"channel",game_channel_name);
    if(utils.is_file_exists(game_channel_root) == false)
    {
        console.log(`渠道路径不存在:${game_channel_root}`);
        process.exit(0);
    }
}

//检查游戏ID
function checkGameId()
{
    //先检查单独渠道
    let game_id_txt = path.join(game_root,`gameid-${game_channel_name}.txt`);
    if(utils.is_file_exists(game_id_txt) == false)
    {
        //在检查公用是否公用id
        game_id_txt = path.join(game_root,`gameid.txt`);
        if(utils.is_file_exists(game_id_txt) == false)
        {
            console.log(`配置${game_id_txt}`);
            process.exit(0);
        }
    }

    game_id = utils.readFileSync(game_id_txt).toString();
    if(game_id == "")
    {
        console.log(`游戏id不能为空:${game_id_txt}`);
        process.exit(0);
    }
}

//检查发布模式
function checkDebug()
{
    is_debug = process.argv[5] == "debug";
}


//检查横竖屏
function checkOrientation()
{
    let tmp = path.join(game_root,"orientation.txt");
    if(utils.is_file_exists(tmp) == false)
    {
        console.log(`横竖屏配置文件不存在:${tmp}`);
        process.exit(0);
    }
    game_orientation = utils.readFileSync(tmp).toString();
}

//0.检查命令行参数
checkArgs();
//1.检查游戏目录
checkGameDir();
//2.检查渠道
checkChannel();
//3.检查游戏ID
checkGameId();
//4.检查发布模式 debug or release
checkDebug();
//5.检查横竖屏
checkOrientation();

console.log(`当前工程路径:${game_root}`);
console.log(`当前渠道路径:${game_channel_root}`);

//游戏工程根目录
M.game_root = game_root;
//游戏类型目录
M.game_type_root = game_type_root;
//打包的渠道目录
M.game_channel_root = game_channel_root;
//渠道名
M.game_channel_name = game_channel_name;

//配置路径 xlsx 
M.game_config_root = path.join(game_root, "resources/config");
//游戏脚本根目录
M.game_scripts_root = path.join(game_root, "assets/scripts");
//游戏 Diationary.ts 路径
M.game_dictionary_ts_path = path.join(game_root, "assets/scripts/framework/libs/data_structure/Diationary.ts");
//游戏id
M.game_id = game_id;
//发布模式
M.is_debug = is_debug;
//tool根目录
M.tool_root = tool_root;
//bin目录
M.bin_dir = path.join(M.tool_root,"bin");
//res module 目录
M.game_res_modules_root = path.join(game_root, "assets/res/modules");
//script module 目录
M.game_scripts_modules_root = path.join(game_root, "assets/scripts/modules");
//game_proto root
M.game_proto_root = path.join(game_root, "protos");
//game_type_proto_root
M.game_type_proto_root = path.join(game_type_root, "00.tools", "sdk", "protos");
//common_proto_root
M.common_proto_root = path.join(tool_root,"sdk","protos");
//web root
M.web_root = path.join(game_root,"build",M.game_id);
//vscode root
M.vscode_root = path.join(game_root,".vscode");
//屏幕方向 取值 竖屏=>[portrait]  横屏=>[landscape]
M.game_orientation = game_orientation;

module.exports = M;