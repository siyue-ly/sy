let log = require("./node/utils/log");
let process = require("process");
let run_script_all_games = require("./node/run_script_all_game_implement");

// process.argv[2] = "xlsx2ts.js"        //脚本名称
// process.argv[3] = "default ";      //渠道名称
// process.argv[4] = "debug";       //打包类型

if(process.argv.length < 5)
{
    log.log_error(`参数不正确:\n 
    node 
    run_script_all_game.js 
    script.js 
    game_type 
    game_dir 
    [default] 
    [debug|release]`);
    process.exit(0);
}
let script_root = __dirname;
run_script_all_games.execute(process.argv.slice(2), script_root);