let project = require("./project");
let make_svn_version_implement = require("./node/make_svn_version_implement");

make_svn_version_implement.execute(project.game_root);