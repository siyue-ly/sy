let project = require("./project");

let syn_cmds_implements = require("./node/syn_cmds_implements");

syn_cmds_implements.execute(project);

