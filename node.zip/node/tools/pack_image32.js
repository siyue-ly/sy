let project = require("./project");
let path = require("path");
let utils = require("./node/utils/utils");
let shelljs = require("shelljs");
let M = {};
M.public_project_dir = "";


M.doCmdNormal = function(sheet_dir, plist_file, pic_file, format)
{
    let opt = format == "png" ? "--opt RGBA8888" : "--opt RGB888";
    let texture_format = format == "png" ? `--texture-format png` : "--texture-format jpg";
    let jpg_quality = (format  == "jpg" ? "--jpg-quality 80" : "");
    let size_constraints = `--size-constraints AnySize --max-size 4096`;
    let cmd_param =  `${texture_format} ${opt} ${size_constraints} ${jpg_quality}\
    --tracer-tolerance 100  \
    --pack-mode  Best \
    --algorithm Basic  \
    --trim-mode Polygon \
    --trim-margin 1  \
    --scale-mode Smooth`

    let command =  `TexturePacker.exe ${cmd_param}  --data ${plist_file} --sheet ${pic_file} ${sheet_dir}`
    return shelljs.exec(command);
}


M.doModuleHelp = function(target_dir, module_name, atlas_dir) {

    if (!utils.is_dir(target_dir)) return;
    let sheet_dirs = utils.list_dir_no_rescusion(target_dir);
    let format = atlas_dir.indexOf("jpg") != -1 ? "jpg" : "png";

    let num = 0;
    let sheet_dir = "";
    let plist_file = "";
    let pic_file = "";
    let child_dir_name = "";
    for (num = 0; num < sheet_dirs.length; ++num) {
        child_dir_name = sheet_dirs[num];
        sheet_dir = path.join(target_dir, child_dir_name);
        plist_file = path.join(M.public_project_dir, "assets", "res", "modules", module_name, "res", atlas_dir, child_dir_name + ".plist");
        pic_file = path.join(M.public_project_dir, "assets", "res", "modules", module_name, "res", atlas_dir, child_dir_name  + `.${format}`);
        M.doCmdNormal(sheet_dir, plist_file, pic_file, format);
    }
}

M.doModule = function(parent_path, module_name) {
    let module_res_root = path.join(parent_path, module_name, "res");
    let dirs = utils.list_dir_no_rescusion(module_res_root);
    for (let num = 0; num < dirs.length; ++num) {
        let target_dir = path.join(module_res_root, dirs[num]);
        M.doModuleHelp(target_dir, module_name, dirs[num]);
    }
}


M.execute = function(public_project_dir) 
{
    M.public_project_dir = public_project_dir;
    let resources_atlas_res_modules = path.join(M.public_project_dir, "resources_atlas_32", "res", "modules");
    if(utils.is_file_exists(resources_atlas_res_modules) == false)
    {
        return;
    }
    let dirs = utils.list_dir_no_rescusion(resources_atlas_res_modules);
    let num = 0;
    for (num = 0; num < dirs.length; ++num) 
    {
        M.doModule(resources_atlas_res_modules, dirs[num]);
    }
}

M.execute(project.game_root);
