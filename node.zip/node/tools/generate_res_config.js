let project = require("./project");

let generate_res_config_implement = require("./node/generate_res_config_implement");

generate_res_config_implement.execute(project.game_scripts_modules_root,project.game_res_modules_root);


