
let project = require("./project");

let generate_implement = require("./node/generate_proto_implement");

generate_implement.execute(project);
