// xslx 生成 TS 文件
let project = require("./project");

let xlsl2ts_implement = require("./node/xlsl2ts_implement");


xlsl2ts_implement.execute(project);