let project = require("./project");

let pack_image_implement = require("./node/pack_image_implement");

pack_image_implement.execute(project.game_root);
