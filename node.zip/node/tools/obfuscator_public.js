//混淆swg.js文件   client_dev_tools/build-templates/public/swg*.js

let path = require("path");

let obfuscator_public_implement = require("./node/obfuscator_public_implement");

let dir = __dirname;

let swg_src_dir = path.join(dir, "build-templates", "public");

let swg_dst_dir = path.join(dir, "build-templates", "public_obfuscator");

obfuscator_public_implement.execute(swg_src_dir, swg_dst_dir);