let project = require("./project");

let pack_font_implement = require("./node/pack_font_implement");


pack_font_implement.execute(project);
