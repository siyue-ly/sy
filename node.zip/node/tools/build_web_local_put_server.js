let project = require("./project");
let build_web_local_put_server_implement = require("./node/build_web_put_server_implement");
let pack = require("./build_web_help");

let ssh_config = {};

//ssh服务器主机
ssh_config.host = "192.168.18.133";

//ssh服务器用户名
ssh_config.username = "root";

//ssh服务器密码
ssh_config.password= "Weberver133";

//上传zip到ssh服务器目录
ssh_config.web_root_path = "/home/web/game-h5";

//ssh服务器端口
ssh_config.port = 22;


async function  pack_upload ()
{
    //1.打包
    await pack();
    
     //2.上传
    build_web_local_put_server_implement.execute(ssh_config, project);
}

pack_upload();