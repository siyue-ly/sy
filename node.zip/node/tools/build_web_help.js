let project = require("./project");
let build_web_implement = require("./node/build_web_implement");
let cp_channel_implement = require("./node/cp_channel_implement");
let make_svn_version_implement = require("./node/make_svn_version_implement");
let xlsl2ts_implement = require("./node/xlsl2ts_implement");
let generate_res_config_implement = require("./node/generate_res_config_implement");




module.exports = async function pack ()
{
    //0.svn更新
    make_svn_version_implement.execute(project.game_root);

    //1.拷贝渠道资源
    cp_channel_implement.execute(project);


    //2.导出语言包
    xlsl2ts_implement.execute(project);


    //3.导出资源路径config
    generate_res_config_implement.execute(project.game_scripts_modules_root, project.game_res_modules_root);

    //4.打包
    await build_web_implement.execute(project,project.is_debug, project.game_orientation);
    
}
