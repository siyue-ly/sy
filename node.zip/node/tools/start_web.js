
let project = require("./project");

let start_web_implement = require("./node/start_web_implement");

start_web_implement.execute(project.web_root);