let path = require("path");
let utils = require("./utils/utils");
let shelljs = require("shelljs");
let log = require("./utils/log")

let M = {};
M.project = null;


M.cpCmds2Game = function(src_dir,dst_dir)
{
    let arr = utils.recursion_list_all_files(src_dir,".bat");
    let src_file = "";
    let dst_file = "";
    for(let i = 0;i < arr.length; ++i)
    {
        src_file = arr[i].file_path;
        dst_file = path.join(M.project.game_root,"tools",arr[i].base_name);
        shelljs.cp("-f",src_file, dst_file);
        log.log_msg(`cp ${src_file}  ===>  ${dst_file}`);
    }
}

M.execute = function(project)
{
    M.project = project;
    let tool_cmds_path = path.join(M.project.tool_root,"cmds");
    let game_tools_path =  path.join(M.project.game_root,"tools");
    
    if(utils.is_file_exists(tool_cmds_path) == false)
        return;
    if(utils.is_file_exists(game_tools_path) == false)
        return;
    M.cpCmds2Game(tool_cmds_path, game_tools_path);
}

module.exports = M;