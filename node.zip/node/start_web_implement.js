let M = {};



M.execute = function(dir)
{
    console.log(`web-root:${dir}`);
    var express = require('express');
    var path = require('path');
    var app = express();
    app.all('*', function (req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type");
        res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
        res.header("Cache-Control","no-store");//304
        next();
      });
    
    app.use(express.static(dir));
    app.listen(8000);
    
}

module.exports = M;