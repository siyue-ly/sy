let shelljs = require("shelljs");
let fs = require("fs");
let log = require("./log");
const path = require("path");
let xl = require("node-xlsx");
let os = require("os");
let child_progress = require("child_process");
const { log_error } = require("./log");
const crypto = require('crypto');
let process = require("process");


let M = {};

M.isTempFile = function(file_path) {
    let temp_file_flag = "~$";
    return file_path.indexOf(temp_file_flag) != -1;
}

M.exec = function(command) {
    return shelljs.exec(command);
}

M.read_xlsx = function(src_file) {
    if (!M.is_file_exists(src_file)) {
        log.log_error(`${src_file} is not exists!`);
        return null;
    }
    let sheets = xl.parse(src_file);
    return sheets;
}

M.is_windos_os = function() {
    let os_str = os.type();
    return os_str == "Windows_NT";
}

// 判断是不是目录
M.is_dir = function(dir_name) {
        return fs.statSync(dir_name).isDirectory();
    }
    // 同步写入文件
M.writeFileSync = function(file_path, content) {
    if (M.is_file_exists(file_path)) {
        shelljs.rm("-f", file_path);
    }
    fs.writeFileSync(file_path, content);
    log.log_msg(`write ${file_path} success!`);
}
M.readFileSync = function(file_path) {
    return fs.readFileSync(file_path);
}

// 文件和文件夹是否存在
M.is_file_exists = function(dir_name) {
    let is_ok = fs.existsSync(dir_name);
    return is_ok;
}

M.get_file_name_no_extname = function(file) {
    let base_name = path.basename(file);
    let extname = path.extname(file);
    let file_name = base_name.replace(extname, "");
    return file_name;
}

// 列出所有的文件
M.recursion_list_all_files = function(dir_name, end_fix = null,end_fix2 = null) {

    if (!M.is_file_exists(dir_name)) {
        log.log_error(`${dirname} is not exists!`);
        return null;
    }
    if (!M.is_dir(dir_name)) {
        log.log_error(`${dirname} is not directory!`);
        return null;
    }
    let ret = [];
    let files_array = shelljs.ls("-RA", dir_name);
    for (let i = 0; i < files_array.length; ++i) {
        let file = path.join(dir_name, files_array[i]);
        if (M.is_dir(file)) {
            continue;
        }
        let absolute_path = path.dirname(file);
        let relative_path = path.dirname(files_array[i]);
        let item = {};
        item.absolute_path = absolute_path;
        item.relative_path = relative_path;
        item.base_name = path.basename(file);
        if (end_fix) {
            let extname = path.extname(file);
            if (extname == end_fix) {
                item.file_path = file;
                ret.push(item);
            }
        }
        else if(end_fix2)
        {
            let extname = path.extname(file);
            if (extname == end_fix2) {
                item.file_path = file;
                ret.push(item);
            }
        } 
        else 
        {
            item.file_path = file;
            ret.push(item);
        }
    }

    return ret;
}

//列出当前文件夹下的所有文件夹
M.list_dir_no_rescusion = function(dir) {
    let array = shelljs.ls(dir);
    let ret_dirs = [];
    for (let i = 0; i < array.length; ++i) {
        if (M.is_dir(path.join(dir, array[i]))) {
            ret_dirs.push(array[i])
        }
    }
    return ret_dirs;
}


// 创建enum 类型定义的字符串
M.create_enum_str_content = function(enum_name, key_value_obj) {
    let content = `export enum ${enum_name}\n`;
    content += "{\n\n";
    for (key in key_value_obj) {
        content += `\t${key} = "${key_value_obj[key]}",\n`;
    }
    content += "\n}\n";

    return content;
}

M.create_enum_number_content = function(enum_name, key_value_obj) {
    let content = `export enum ${enum_name}\n`;
    content += "{\n\n";
    for (key in key_value_obj) {
        content += `\t${key} = ${key_value_obj[key]},\n`;
    }
    content += "\n}\n";

    return content;
}


M.create_exports_files = function(file_name, key_value_object) {
    let content = ""
    for (let key in key_value_object) {
        content += key_value_object[key];
        content += "\n";
    }
    content += "\n";
    content += `export default {};`;
    return content;
}

//列出文件夹下的所有文件 不包括文件夹
M.list_common_files = function(dir) {
    let ret = [];
    let array = shelljs.ls(dir);
    for (let i = 0; i < array.length; ++i) {
        let child_dir_name = array[i];
        if (M.is_dir(path.join(dir, child_dir_name))) {
            continue;
        }
        let extname = path.extname(array[i]);
        if (extname == ".meta") {
            continue;
        }
        ret.push(array[i]);
    }
    return ret;
}

M.list_prefab_files = function(dir) {
    let ret = [];
    let array = M.recursion_list_all_files(dir, ".prefab");
    for (let i = 0; i < array.length; ++i) {
        let item = array[i];
        if (item.relative_path == ".") {
            ret.push(item.base_name);
        } else {
            ret.push(path.join(item.relative_path, item.base_name));
        }
    }
    return ret;
}

M.list_spine_dir_files = function(dir) {
    let array = M.recursion_list_all_files(dir, ".atlas");
    let ret_array = [];
    for (let i = 0; i < array.length; ++i) {
        ret_array.push(array[i].base_name);
    }
    return ret_array;
}

M.list_dir_files = function(dir, extern) {
    let array = M.recursion_list_all_files(dir, extern);
    let ret_array = [];
    let base_name = "";
    for (let i = 0; i < array.length; ++i) {
        base_name = array[i].base_name;
        ret_array.push( base_name.substring(0,base_name.lastIndexOf(extern)));
    }
    return ret_array;
}

M.replace_path_to_unix_path = function(path) {
    let unix_path = path.replace(/\\/g, "/");
    return unix_path;
}

//取消文件的后缀名
M.cut_extname = function(file) {
    let extname = path.extname(file);
    if (extname != "") {
        file = file.replace(extname, "");
    }
    return file;
}

M.get_ts_head = function() {
    return `//This file auto genarate by nodejs , you should not modify it!\n\n`;
}

M.getCocosCreatorCMD = function() {
    if (M.is_windos_os()) {
        return "CocosCreator.exe";
    }
    return "CocosCreator";
}

M.openDir = function(dir_path) {
    if (M.is_windos_os()) {
        child_progress.exec(`start "" "${dir_path}`);
    } else {
        child_progress.exec(`open "${dir_path}"`);
    }
}

M.zipDir = async function(dir_path, zip_name,finish) {
    const compressing = require('compressing');
    await compressing.zip.compressDir(dir_path, zip_name)
    finish && finish();
}

M.getSvnCmdPath = function() {
    if (M.is_windos_os()) {
        let project = require("./../../project");
        return path.join(project.bin_dir, "svn/svn.exe")
    }
    return "svn"
}

M.getSvnInfo = function(path) {
    let svn = M.getSvnCmdPath();
    let cmd = `${svn} info ${path}`;
    let shelljs_ret = M.exec(cmd);
    let code = shelljs_ret.code;
    if (code) {
        log_error("exe svn cmd getSvnServerVersion error!");
        exit(-1);
    }
    let stdout = shelljs_ret.stdout;
    let arr = null;
    if (M.is_windos_os()) {
        arr = stdout.split("\r\n");
    } else {
        arr = stdout.split("\n");
    }
    return arr;
}
M.getSvnServerVersion = function(path) {
    let arr = M.getSvnInfo(path);
    return parseInt(arr[6].split(":")[1]);
}
M.getSvnLocalVersion = function(path) {
    let svn = M.getSvnCmdPath();
    let cmd = `${svn} log --limit 1 ${path}`;
    let shelljs_ret = M.exec(cmd);
    let code = shelljs_ret.code;
    if (code) {
        log_error("exe svn cmd getSvnLocalVersion error!");
        exit(-1);
    }
    let arr = null;
    if (M.is_windos_os()) {
        arr = shelljs_ret.stdout.split("\r\n");
    } else {
        arr = shelljs_ret.stdout.split("\n");
    }
    let version = parseInt(arr[1].split(" | ")[0].substring(1));
    return version;
}

M.svnUp = function(path) {
    console.log(`svn up ${path}`);
    let svn = M.getSvnCmdPath();
    let cmd = `${svn} up ${path}`;
    let shelljs_ret = M.exec(cmd);
    let code = shelljs_ret.code;
    if (code) {
        log_error("exe svn cmd getSvnLocalVersion error!");
        exit(-1);
    }
}


M.cdDir = function(dir) {
    shelljs.cd(dir);
}


M.md5 = function(file_path)
{
    const buffer = fs.readFileSync(file_path);
    const hash = crypto.createHash('md5');
    hash.update(buffer, 'utf8');
    const md5 = hash.digest('hex');
    return md5;

}

M.readFileSyncJsonObject = function(file_path)
{
    if(M.is_file_exists(file_path))
    {
        let content = M.readFileSync(file_path);
        let obj = JSON.parse(content);
        return obj;
    }
    return {};
}

M.renameDir = function(src,dst)
{
    if(!M.is_file_exists(src)) return;
    
    if(src == dst) return;
    shelljs.rm("-rf",dst);
    let code = shelljs.mv(src,dst);
}


//获取深层文件夹名字
M.get_deep_dir_name = function(dir)
{
    let index = dir.lastIndexOf("/");
    if(index ==  -1) return index;
    return dir.substring(index + 1);
}


//打包图集 sheetDir
M.packAtlas = function(sheet_dir, plist_file, pic_file, format)
{
    let config_obj = M.getPackConfig(sheet_dir);
    let opt = format == "png" ? "--opt RGBA8888" : "--opt RGB888";
    let texture_format = `--texture-format png8`;
    let opt_level = "--png-opt-level 4";
    let jpg_quality = "--jpg-quality 80";
    //默认是裁剪
    let trim = `--trim-mode Polygon  --trim-margin 1`;
    if(format == "png")
    {
        texture_format = "--texture-format png8";
        if(config_obj && config_obj["png_format"])
        {
            texture_format = `--texture-format ${config_obj["png_format"]}`;
        }
        if(config_obj && config_obj["png_opt_level"])
        {
            opt_level = `--png-opt-level ${config_obj["png_opt_level"]}`;
        }
        //表示裁不剪透明区域
        if(config_obj && config_obj["trim"] == 0)
        {
            trim = "--trim-mode None --alpha-handling  KeepTransparentPixels"
        }
        jpg_quality = "";
    }
    else if(format == "jpg")
    {
        texture_format = "--texture-format jpg";
        opt_level = "";
        trim = "";
        if(config_obj && config_obj["jpg_quality"])
        {
            jpg_quality = `--jpg-quality ${config_obj["jpg_quality"]}`
        }
    }


    let size_constraints = `--size-constraints AnySize --max-size 4096`;
    let cmd_param =  `${texture_format} ${opt} ${size_constraints} ${jpg_quality} ${opt_level} ${trim}\
    --tracer-tolerance 100  \
    --pack-mode  Best \
    --algorithm Basic  \
    --dither-type PngQuantHigh \
    --scale-mode Smooth`;

    let cmd =  `TexturePacker.exe ${cmd_param}  --data ${plist_file} --sheet ${pic_file} ${sheet_dir}`;
    M.exec(cmd);
}

M.getCmdBigPicPng = function(sheet_dir)
{
    let config_obj = M.getPackConfig(sheet_dir);
    let opt  = "--opt RGBA8888";
    let texture_format =`--texture-format png8`;
    let size_constraints = `--size-constraints AnySize --max-size 4096`;
    let opt_level = "--png-opt-level 4";
    if(config_obj && config_obj["png_format"])
    {
        texture_format = `--texture-format ${config_obj["png_format"]}`;
    }
    if(config_obj && config_obj["png_opt_level"])
    {
        opt_level = `--png-opt-level ${config_obj["png_opt_level"]}`;
    }
    return `TexturePacker.exe  ${texture_format} ${opt} ${size_constraints} ${opt_level}\
    --tracer-tolerance 100\
    --pack-mode  Best\
    --algorithm Basic\
    --dither-type PngQuantHigh\
    --trim-mode None\
    --alpha-handling  KeepTransparentPixels\
    --trim-margin 0\
    --disable-rotation\
    --extrude 0\
    --scale-mode Smooth`;
}
M.getCmdBigPicJpg = function(sheet_dir)
{
    let config_obj = M.getPackConfig(sheet_dir);
    let opt  = "--opt RGB888";
    let texture_format =`--texture-format jpg`
    let jpg_quality = "--jpg-quality 80"
    if(config_obj && config_obj["jpg_quality"])
    {
        jpg_quality = `--jpg-quality ${config_obj["jpg_quality"]}`
    }
    let size_constraints = `--size-constraints AnySize --max-size 4096`;
    return `TexturePacker.exe  ${texture_format} ${opt} ${size_constraints} ${jpg_quality}\
    --tracer-tolerance 100\
    --pack-mode  Best\
    --algorithm Basic\
    --trim-mode None\
    --trim-margin 0\
    --disable-rotation\
    --extrude 0\
    --scale-mode Smooth`;
}

M.getPackConfig = function(sheet_dir)
{
    let ret_obj = {};
    let xlsx_path = path.join(sheet_dir, "config.xlsx");
    if(M.is_file_exists(xlsx_path) == false)
    {
        return null; 
    }
    let array = M.read_xlsx(xlsx_path)[0]["data"];
    let params = ["png_format", "png_opt_level", "jpg_quality", "trim"];
    for(let i = 3;i < array.length; ++i)
    {
        if(params.includes(array[i][0]))
        {
            ret_obj[array[i][0]] = array[i][1]; 
        }
    }

    //参数安全性检查
    if("png_format" in ret_obj)
    {
        let png_formats = ["png", "png8"];
        if(png_formats.includes(ret_obj["png_format"]) == false)
        {
            log_error(`${xlsx_path} 配置错误`);
            log_error(`png_format 格为 png 或者 png8`);
            process.exit(0);
        }
    }
    if("png_opt_level" in ret_obj)
    {
        if(isNaN(ret_obj["png_opt_level"]))
        {
            log_error(`${xlsx_path} 配置错误`);
            log_error(`png_opt_level 参数应该为一个数字 {0,1,2,3,4,5,6,7} 的一个整数`);
            process.exit(0);
        }
    }
    if("jpg_quality" in ret_obj)
    {
        if(isNaN(ret_obj["jpg_quality"]))
        {
            log_error(`${xlsx_path} 配置错误`);
            log_error(`jpg_quality 参数应该为一个数字 {0-100} 之间的整数`);
            process.exit(0);
        }
    }
    if("trim" in ret_obj)
    {
        if(isNaN(ret_obj["trim"]))
        {
            log_error(`${xlsx_path} 配置错误`);
            log_error(`trim 参数应该为一个数字 0 ,1`);
            process.exit(0);
        }
    }
    return ret_obj;
}

//压缩单张图片
M.compressSinglePic = function(src_pic, plist_file, pic_file)
{
    let sheet_dir = path.dirname(src_pic);
    let cmd_option = pic_file.indexOf(".png") > -1 ? M.getCmdBigPicPng(sheet_dir) : M.getCmdBigPicJpg(sheet_dir);
    let cmd =  `${cmd_option}  --data ${plist_file} --sheet ${pic_file} ${src_pic}`
    M.exec(cmd);
}

M.getCmdPackAudio = function(input,output)
{
    let exe_path = "";
    if (M.is_windos_os()) {
        let project = require("./../../project");
        exe_path =  path.join(project.bin_dir, "audio/lame.x64-avx.exe");
    }
    if(!exe_path)
    {
        console.error(`当前不是Windos平台,不支持lame.x64-avx.exe`);
        process.exit(0);
    }
    return `${exe_path} -B64 -b20 -V9 ${input} ${output}`;
}
M.obfuscatorJS = function(input_file, output_file)
{
    //参数选项
    // https://github.com/javascript-obfuscator/javascript-obfuscator
    let stat = fs.statSync(input_file);
    let src_size = stat.size;
    let option = "--options-preset  high-obfuscation";
    let cmd = `npx javascript-obfuscator ${input_file} --output ${output_file} ${option}`;
    M.exec(cmd);
    stat = fs.statSync(output_file);
    let dst_size = stat.size;
    if(dst_size > src_size)
    {
        log.log_msg(`加密后增加大小:${M.getHumanSize(dst_size - src_size)}`);
    }
}
M.getHumanSize = function(size)
{
    if(size < 1024)
    {
        return `${size} Bytes`;
    }
    if(size < 1024 * 1024)
    {
        return `${(size/1024).toFixed(2)} K`;
    }
    if(size < 1024 * 1024 * 1024)
    {
        return `${(size/1024/1024).toFixed(2)} M`;
    }
    return size + "Byte";
}
module.exports = M;