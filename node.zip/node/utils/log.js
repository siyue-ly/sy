
let M = {};
M.log_error = function(msg)
{
    console.log('\x1b[91m',msg);
}

M.log_msg = function(msg)
{
    console.log('\x1B[32m',msg);
}

M.log_warn = function(msg)
{
    console.log('\x1B[43m',msg);
}


module.exports = M;