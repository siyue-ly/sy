
let utils = require("./utils/utils");
let path = require("path");
let Pako = require("pako");
let fs = require("fs");

let M = {};
M.input_dir = "";
M.output_dir = "";

M.isExclude = function(file_name)
{
    let exclude_list = [
        "cocos-debug-v1.js", 
        "cocos-release-v1.js", 
        "jszip.min.js",
        "message.js",
        "NoSleep.min.js",
        "ondebug-v14.js",
        "orientationchangeend.min.js",
        "vconsole.min.js"
    ];
    return exclude_list.indexOf(file_name) > -1;
}

M.doit  = function(file_name)
{
    if(M.isExclude(file_name))
    {
        return;
    }
    let input_file = path.join(M.input_dir, file_name);
    let output_file = path.join(M.output_dir, file_name);
    utils.obfuscatorJS(input_file, output_file);
    M.pakoJSFile(M.output_dir, file_name);
    utils.openDir(M.output_dir);
    console.log(file_name)
}

M.pakoJSFile = function(dir, file_name)
{
    let file_path =  path.join(dir, file_name)
    let content = utils.readFileSync(file_path);
    let buffer = M.encode(content);
    let output_file = file_path.replace(".js", ".bin");
    fs.writeFileSync(output_file, buffer);
}

M.encode = function(str)
{
    let pako_str = Pako.deflate(str);
    return Buffer.from(pako_str);
}

M.execute = function(input_dir, output_dir)
{
    M.input_dir = input_dir;
    M.output_dir = output_dir;
    let arr = utils.recursion_list_all_files(input_dir, ".js")
    for(let i = 0;i < arr.length; ++i)
    {
        M.doit(arr[i].base_name);
    }
}

module.exports = M;