let utils = require("./utils/utils");
const { log_error, log_msg } = require("./utils/log");
let path = require("path");



let M = {};
M.project_path= "";

M.make = function() {
    utils.svnUp(M.project_path)
}
M.execute = function(project_path) {
    M.project_path = project_path;
    M.make();
}

module.exports = M;