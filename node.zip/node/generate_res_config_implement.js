let utils = require("./utils/utils");
const { log_msg, log_error } = require("./utils/log");
let path = require("path");



let M = {}

M.generate_model_res_config_help = function(model_name,res_dir_name)
{
    let res_path = path.join(M.project_res_modules_root,model_name,"res",res_dir_name);
    let files_array = [];
    if(res_dir_name == "spine" || res_dir_name == "spin")
    {
        files_array = utils.list_spine_dir_files(res_path);
    }
    else if(res_dir_name == "pic")
    {
        files_array = utils.list_dir_files(res_path, ".plist");
    }
    else if(res_dir_name == "prefab")
    {
        files_array = utils.list_prefab_files(res_path);
    }
    else if(res_dir_name == "sound" || res_dir_name == "audio")
    {
        files_array = utils.list_dir_files(res_path, ".mp3");
    }
    else
    {
        files_array = utils.list_common_files(res_path); 
    }
    for(let i = 0;i < files_array.length;++i)
    {
        let file_path = utils.replace_path_to_unix_path(files_array[i]);
        if(res_dir_name == "pic")
        {

        }
        else
        {
            file_path = utils.cut_extname(file_path);
        }
        files_array[i] = file_path;
    }
    
    let enum_key_value_object = {};
    for(let i = 0; i < files_array.length;++i)
    {
        let file_name = utils.get_file_name_no_extname(files_array[i]);
        enum_key_value_object[file_name] = `res/${res_dir_name}/${files_array[i]}`; 
    }
    let content = utils.create_enum_str_content(res_dir_name,enum_key_value_object);
    return content;
}

M.generate_model_res_config = function(model_name)
{
    let res_config_dir = path.join(M.project_scripts_modules_root,model_name,"config");
    if(!res_config_dir)
    {
        log_error(`${res_config_dir} is not exists!`);
        return;
    }
    let model_path = path.join(M.project_res_modules_root,model_name,"res");
    let is_dir = utils.is_dir(model_path);
    if(!is_dir)
    {
        log_error(`${model_path} is not a dictory!`);
        return;
    }
    let res_dir = utils.list_dir_no_rescusion(model_path);
    let exports_content_object = {};
    for(let i = 0;i < res_dir.length;++i)
    {
        let content = M.generate_model_res_config_help(model_name,res_dir[i]);
        exports_content_object[res_dir[i]] = content;
    }
    let content = utils.get_ts_head();
    content += utils.create_exports_files(`${model_name}_res_config`,exports_content_object);
    let res_config_path = path.join(res_config_dir,`${model_name}_res_config.ts`);
    utils.writeFileSync(res_config_path,content);
}



M.generate_res_config = function()
{
    let model_array = utils.list_dir_no_rescusion(M.project_res_modules_root);
    for(let i = 0;i < model_array.length;++i)
    {
        M.generate_model_res_config(model_array[i]);
    }
}

M.execute = function(project_scripts_modules_root,project_res_modules_root)
{
    M.project_scripts_modules_root = project_scripts_modules_root;
    M.project_res_modules_root = project_res_modules_root;

    M.generate_res_config();
}

module.exports = M;