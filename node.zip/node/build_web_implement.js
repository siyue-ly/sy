let utils = require("./utils/utils");
let Log = require("./utils/log");
let shell = require("shelljs");
let path = require("path")
let fs = require("fs");
let obfuscator_implement = require("./javascript-obfuscator_implement");

let M = {};

M.unzip_extern_table = {
    ".ttf" : "1",
};

M.is_debug = true;

M.game_root = "";
M.game_id = "";
M.orientation = "";
M.project = null;

M.get_build_web_param = function() {

    let cmd = `--path ${M.project_root} --build "platform=web-mobile;debug=${M.is_debug};md5Cache=true;webOrientation=${M.orientation}"`;
    cmd += ";mainCompressionType=merge_all_json"
    if (M.is_debug) {
        cmd += ";embedWebDebugger=true"
        cmd += ";vConsloe=true"
    }
    return cmd;
}


M.build_web = async function() {

    let cocos_creator_path = utils.getCocosCreatorCMD();
    let param = M.get_build_web_param();
    let cmd = `${cocos_creator_path} ${param}`;
    utils.exec(cmd);
    //目前只给通信协议文件加密
    if(0)
    {
        if(!M.is_debug)
        {
            obfuscator_implement.execute();
        }
    }

    M.evalSettingJS();
    let src = path.join(M.project_root, "build", "web-mobile");
    let dst = path.join(M.project_root,"build",M.game_id);
    let zipMap = M.getZipBundleMap();
    await this.checkPackZipBundle(zipMap)
    M.checkModifySettingJS(zipMap);
    M.rmDirtyFiles(src);

    let build_path = path.join(M.project_root, "build");
    shell.cd(build_path);
    utils.renameDir(src,dst);
    shell.cd(build_path);
  
    await utils.zipDir(dst, `${M.game_id}.zip`);
    utils.openDir(build_path);
    Log.log_msg(`build  ${M.game_id} web success!`);
}
M.checkPackZipBundle =  async function(zipMap)
{
    for(let key in zipMap)
    {
        if(zipMap[key])
        {
            await M.zipBundle(key);
        }
    }
}

M.getZipBundleMap = function()
{
    let settingjs = shell.ls("*.js").stdout;
    settingjs = settingjs.replace("\n",'');
    let bundle_zip_config_path = path.join(M.project_root, "resources", "config", "modules", "common", "config", "bundle_zip_config.xlsx");
    if(utils.is_file_exists(bundle_zip_config_path) == false)
    {
        Log.log_error(`文件不存在:${bundle_zip_config_path}`);
        process.exit(0);
    }
    let array = utils.read_xlsx(bundle_zip_config_path)[0].data;
    let bundle_name_index = -1;
    let isZip_index = -1;
    for(let i = 0;i < array[0].length; ++i)
    {
        if(array[0][i] == "bundle_name")
        {
            bundle_name_index = i;
        }
        if(array[0][i] == "isZip")
        {
            isZip_index = i;
        }
    }
    
    if(bundle_name_index == -1 || isZip_index == -1)
    {
        Log.log_error(`配置文件错误,缺少键 [bundle_name] [isZip]:${bundle_zip_config_path}`);
        process.exit(0);
    }
    let zipMap = {};
    for(let i = 3; i < array.length; ++i)
    {
        zipMap[array[i][bundle_name_index]] = array[i][isZip_index];
    }

    return zipMap;
}
M.checkModifySettingJS = function(zipMap)
{
    let zipbundle_jsonstr = JSON.stringify(zipMap);
    let settingjs_path = M.getSettingJSPath();
    let zipbundle_config = `zipbundle:${zipbundle_jsonstr}`;
    shell.sed("-i", "platform", `${zipbundle_config},platform`, settingjs_path);
}
M.getSettingJSPath = function()
{
    let src_path = path.join(M.project_root, "build", "web-mobile", "src");
    shell.cd(src_path);
    let settingjs = shell.ls("*.js").stdout;
    settingjs = settingjs.replace("\n",'');
    let settingjs_path = path.join(M.project_root, "build", "web-mobile", "src", settingjs);
    if(utils.is_file_exists(settingjs) == false)
    {
        Log.log_error(`文件不存在:${settingjs_path}`);
        process.exit(0);
    }
    return settingjs_path;
}
M.evalSettingJS = function()
{
    let settingjs_path = M.getSettingJSPath();
    let window = {};
    global.window = window;
    let content = fs.readFileSync(settingjs_path).toString();
    eval(content)
}
M.zipBundle = async function(bundle_name)
{
    let assets_path = path.join(M.project_root, "build", "web-mobile", "assets");
    shell.cd(assets_path);
    if(utils.is_file_exists(bundle_name) == false)
    {
        Log.log_error(`bundle不存在:${bundle_name}`);
        process.exit(0);
    }

    let bundleVers = window._CCSettings["bundleVers"];
    let version = bundleVers[bundle_name];
    let zip_bundle_path = path.join(M.project_root, "build", "web-mobile", "assets", bundle_name);
    let zip_file_path = path.join(M.project_root, "build", "web-mobile", "assets", `${bundle_name}.${version}.bin`);
    let opt_func = M.moveUnzipFiles(bundle_name, assets_path);
    await utils.zipDir(zip_bundle_path,`${bundle_name}.${version}.bin`);
    shell.rm("-rf", `${zip_bundle_path}`);
    if(opt_func)
    {
        opt_func();
    }
    M.reWriteBundleZip(zip_file_path);
}


M.moveUnzipFiles = function(bundle_name, asset_path)
{
    let sum_unzips = 0;
    let bundle_path = path.join(asset_path, bundle_name);
    for(let key in M.unzip_extern_table)
    {
        let files = utils.recursion_list_all_files(bundle_path, key);
        sum_unzips  += files.length;
        for(let i = 0;i < files.length; ++i)
        {
            let src_path = path.join(files[i].file_path);
            let dst_dir = path.join(asset_path, `${bundle_name}.bat`, files[i].relative_path);
            let dst_path = path.join(dst_dir, files[i].base_name);
            if(utils.is_file_exists(dst_dir) == false)
            {
                shell.mkdir("-p", dst_dir);
            }
            shell.mv("-f", src_path, dst_path);
        }
    }
    if(sum_unzips <= 0)
    {
        return null;
    }
    let src_bunlde = path.join(asset_path, `${bundle_name}.bat`);
    let rename_bundle_dir = function()
    {
        shell.mv("-f", src_bunlde, bundle_path);
    }
    return rename_bundle_dir;
}

M.reWriteBundleZip = function(zip_file_path)
{
    let src_buf = fs.readFileSync(zip_file_path); 
    let mid_pos = Math.floor(src_buf.byteLength/2)
    let head_buf = src_buf.subarray(0,mid_pos);
    let tail_buf = src_buf.subarray(mid_pos,src_buf.byteLength);
    let dst_buf = Buffer.concat([tail_buf,head_buf]);
    fs.writeFileSync(zip_file_path,dst_buf);
    console.log(`ReWriteBundleZip:${zip_file_path}`);
}

M.rmDirtyFiles = function(web_mobile_path)
{
    shell.cd(web_mobile_path);
    shell.rm("-f", "style-mobile*.css");
    shell.rm("-f", "style-desktop*.css");
    shell.rm("-f", "splash*.png");
    shell.rm("-r", "favicon.*.ico");

    if(utils.is_file_exists("index.html"))
    {
        let str = utils.readFileSync("index.html").toString();
        let index = str.search(/..\/public\/cocos-.*js/i);
        if(index != -1)
        {
            shell.rm("-r", "cocos2d-js*.js");
        }
    }
    
    if (M.is_debug) {
        shell.rm("-f", "vconsole.min*.js");
    }
}

M.write_ver = function()
{
    let app_ver_path = path.join(M.project_root,"assets","scripts","modules","app_ver.ts");
    let date = new Date();
    let year = date.getFullYear() % 100 + "";
    let month = date.getMonth() + 1;
    if(month < 10)
        month = "0" + month;
    let day = date.getDate();
    if(day < 10)
        day = "0" + day;

    let clie_ver = `${year}.${month}.${day}`;

    let str = `export default class app_ver 
{
    //客户端版本号
    public static clie_ver:string = "${clie_ver}";

    //服务器版本号
    public static serv_ver:string = "1";

    public static get_ver():string
    {
        return "v" + app_ver.serv_ver + "_" + app_ver.clie_ver;
    }
}`;

    utils.writeFileSync(app_ver_path,str);
}

M.execute = async function(project,is_debug,orientation) {

    M.project = project;
    M.project_root = project.game_root;
    M.game_id = project.game_id;
    M.is_debug = is_debug;
    M.orientation = orientation;
    M.write_ver();
    await M.build_web();
}

module.exports = M;